CREATE VIEW U_USER_VIEW AS
  select "T_ID","NAME","PASSWORD" from u_user where t_id=5
with check option
/

