CREATE procedure pro_addUser
as
begin
insert into u_user values(u_seq.nextval,'bb','b123');
insert into u_user values(u_seq.nextval,'bb','b123');
insert into u_user values(u_seq.nextval,'bb','b123');
insert into u_user values(u_seq.nextval,'bb','b123');
commit;
end;
/

